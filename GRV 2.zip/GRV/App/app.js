// require("reflect-metadata");

const AppServer = require('../index');
const PORT = 3000
const debug = require("debug");
const { createServer } = require('http');

AppServer.set("port",PORT);
const server = createServer(AppServer); //SERVER CREATION

const application = await server.listen(PORT);
// .then(res=>console.log(`Server is listning on port ${PORT}`))
// .catch(err=>console.log("Oops....!!! Something went Wrong...."));


server.on("error",onError);
server.on("Listning",onListening)


function onError(error) {
    console.log(error)
    if (error.syscall !== 'listen') { throw error; }
    const bind = (typeof port === 'string') ? 'Pipe ' + port : 'Port ' + port;
    switch (error.code) {
        case 'EACCES':
            console.error(`${bind} requires elevated privileges`);
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(`${bind} is already in use`);
            process.exit(1);
            break;
        default:
            throw error;
    }
}

function onListening() {
    var addr = server.address();
    var bind = typeof addr === "string" ? "pipe " + addr : "port " + addr.port;
    debug("Listening on " + bind);
}