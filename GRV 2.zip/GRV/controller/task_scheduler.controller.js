import {execute} from './task.controller';
class TaskSchedule {
   constructor(maxparallelTask){
    this.maxparallelTask = maxparallelTask;
    this.task = [];
    this.runningTask = 0;
    this.taskQueue=[];
    this.dependencies = {};
   }
    
   start(){
    this.processQueue();
   }
   
   processQueue(){
    while((this.runningTask < this.maxparallelTask) && this.taskQueue.length>0){
        const task = this.taskQueue.shift();
        if(this.canRunTask()){
            this.runTask(task);
        }else{
            this.taskQueue.unshift(task);
        }
    }
   }

   canRunTask(){
    return this.dependencies.every((dependency)=>{
        const dependencyTask= this.task.find((t)=>t.taskId === dependency);
        return dependencyTask && dependencyTask.finished;
    })
   }

   runTask(){
    this.runningTask+=1;
    execute().then(()=>{
        this.runningTask--;
        this.processQueue();
    })
   }


}

module.exports = new TaskSchedule();