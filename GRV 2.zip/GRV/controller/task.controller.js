class Task {
    constructor(taskId,durations,dependenies){
        this.taskId = taskId;
        this.durations = durations;
        this.dependenies=dependenies;
        this.finished = false;
    }
    execute(){
        return new Promise((res,rej)=>{
            setTimeout(()=>{
                console.log(`Task ${this.taskId} finished`);
                this.finished = true;
                res();
            },this.durations*1000);
        })
    }

}

module.exports = new Task().execute;