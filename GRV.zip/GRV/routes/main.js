const express = require("express");
const routers = express.Router();
const task_controller = require("../controller/task.controller");
const task_scheduler_controller = require("../controller/task_scheduler.controller");

//TESTING SERVER
routers.get('/',(req,res)=>{
    res.status(200).send("It's Up and working............!!! 🍺🍺");
    res.end();
})

routers.post('/task_scheduler', (req,res)=>{
    const request = req.body;

});

// routers.call('*',function (req,res){
//     console.log("ERROR POINT MAIN JS",res)
//     res.status(404).send("404............!!!! Not Found");
//     res.end();
// })

module.exports = routers;